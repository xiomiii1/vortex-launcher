package com.nexus.vortexlauncher.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import java.io.File
import java.io.RandomAccessFile
import java.util.regex.Pattern

object DeviceUtils {

    enum class Architecture {
        ARM32, ARM64, X86, X86_64, UNKNOWN
    }

    fun detectArchitecture(): Architecture {
        val primaryAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: return Architecture.UNKNOWN
        return when {
            primaryAbi.contains("arm64-v8a") -> Architecture.ARM64
            primaryAbi.contains("armeabi-v7a") || primaryAbi.contains("armeabi") -> Architecture.ARM32
            primaryAbi.contains("x86_64") -> Architecture.X86_64
            primaryAbi.contains("x86") -> Architecture.X86
            else -> Architecture.UNKNOWN
        }
    }

    fun getTotalMemory(context: Context): Long {
        val memoryInfo = ActivityManager.MemoryInfo()
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.getMemoryInfo(memoryInfo)
        return memoryInfo.totalMem // Bytes
    }

    fun calculateOptimalRamAllocation(context: Context): Int {
        val totalMemoryMb = getTotalMemory(context) / (1024 * 1024)
        return when {
            totalMemoryMb <= 2048 -> 1024 // 2GB Devices -> Allocate 1GB
            totalMemoryMb <= 4096 -> 2048 // 4GB Devices -> Allocate 2GB
            totalMemoryMb <= 6144 -> 3584 // 6GB Devices -> Allocate 3.5GB
            else -> 4096                  // 8GB+ Devices -> Allocate 4GB safe max for baseline
        }
    }

    fun getCpuCoreCount(): Int {
        return try {
            val dir = File("/sys/devices/system/cpu/")
            val files = dir.listFiles { pathname -> Pattern.matches("cpu[0-9]+", pathname.name) }
            files?.size ?: 1
        } catch (e: Exception) {
            1
        }
    }
}
