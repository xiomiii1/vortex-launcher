package com.nexus.vortexlauncher.ui.theme

import androidx.compose.ui.graphics.Color

val DarkPrimary = Color(0xFF4DEEEA)
val DarkSecondary = Color(0xFF74EBD5)
val DarkTertiary = Color(0xFF9FACE6)
val DarkBackground = Color(0xFF12141C)
val DarkSurface = Color(0xFF1E2230)

val LightPrimary = Color(0xFF006A6A)
val LightSecondary = Color(0xFF4A6363)
val LightTertiary = Color(0xFF4B607C)
val LightBackground = Color(0xFFF4FBFB)
val LightSurface = Color(0xFFEDF4F4)
