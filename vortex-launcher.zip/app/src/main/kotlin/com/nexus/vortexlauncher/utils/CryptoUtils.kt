package com.nexus.vortexlauncher.utils

import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

object CryptoUtils {
    fun verifyChecksum(file: File, expectedSha1: String): Boolean {
        if (!file.exists()) return false
        return try {
            val digest = MessageDigest.getInstance("SHA-1")
            val fis = FileInputStream(file)
            val buffer = ByteArray(8192)
            var bytesRead = fis.read(buffer)
            while (bytesRead != -1) {
                if (bytesRead > 0) {
                    digest.update(buffer, 0, bytesRead)
                }
                bytesRead = fis.read(buffer)
            }
            fis.close()
            val sha1Hex = digest.digest().joinToString("") { "%02x".format(it) }
            sha1Hex.equals(expectedSha1, ignoreCase = true)
        } catch (e: Exception) {
            false
        }
    }
}
