package com.nexus.vortexlauncher.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey val uuid: String,
    val username: String,
    val accessToken: String,
    val clientToken: String,
    val accountType: String, // "OFFLINE" or "MICROSOFT"
    val profilePictureUrl: String?,
    val isSelected: Boolean = false
)
