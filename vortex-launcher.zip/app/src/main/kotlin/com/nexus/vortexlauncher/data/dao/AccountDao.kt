package com.nexus.vortexlauncher.data.dao

import androidx.room.*
import com.nexus.vortexlauncher.data.models.Account
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts")
    fun getAllAccounts(): Flow<List<Account>>

    @Query("SELECT * FROM accounts WHERE isSelected = 1 LIMIT 1")
    suspend class getSelectedAccount(): Account?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: Account)

    @Update
    suspend fun updateAccount(account: Account)

    @Delete
    suspend fun deleteAccount(account: Account)

    @Query("UPDATE accounts SET isSelected = 0")
    suspend fun clearSelections()

    @Transaction
    suspend fun selectAccount(uuid: String) {
        clearSelections()
        QuerySelectAccount(uuid)
    }

    @Query("UPDATE accounts SET isSelected = 1 WHERE uuid = :uuid")
    suspend fun QuerySelectAccount(uuid: String)
}
