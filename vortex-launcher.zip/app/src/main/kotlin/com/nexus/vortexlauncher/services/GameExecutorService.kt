package com.nexus.vortexlauncher.services

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

class GameExecutorService : Service() {

    private val executionJob = SupervisorJob()
    private val executionScope = CoroutineScope(Dispatchers.IO + executionJob)
    private var gameProcess: Process? = null

    companion object {
        const val ACTION_LAUNCH_GAME = "com.nexus.vortexlauncher.action.LAUNCH_GAME"
        const val EXTRA_JAVA_BINARY = "extra_java_binary"
        const val EXTRA_JVM_ARGS = "extra_jvm_args"
        const val EXTRA_CLASSPATH = "extra_classpath"
        const val EXTRA_MAIN_CLASS = "extra_main_class"
        const val EXTRA_GAME_ARGS = "extra_game_args"
        const val EXTRA_GAME_DIR = "extra_game_dir"
        
        const val NOTIFICATION_ID = 202
        const val CHANNEL_ID = "game_channel"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_LAUNCH_GAME) {
            val javaBinary = intent.getStringExtra(EXTRA_JAVA_BINARY) ?: "java"
            val jvmArgs = intent.getStringArrayExtra(EXTRA_JVM_ARGS) ?: emptyArray()
            val classpath = intent.getStringExtra(EXTRA_CLASSPATH) ?: ""
            val mainClass = intent.getStringExtra(EXTRA_MAIN_CLASS) ?: "net.minecraft.client.main.Main"
            val gameArgs = intent.getStringArrayExtra(EXTRA_GAME_ARGS) ?: emptyArray()
            val gameDir = intent.getStringExtra(EXTRA_GAME_DIR) ?: filesDir.absolutePath

            startForeground(NOTIFICATION_ID, createGameNotification())

            executionScope.launch {
                runMinecraftProcess(javaBinary, jvmArgs, classpath, mainClass, gameArgs, gameDir)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun createGameNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Vortex Launcher Engine")
            .setContentText("Minecraft Java Edition is running...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private suspend fun runMinecraftProcess(
        javaBinary: String,
        jvmArgs: Array<String>,
        classpath: String,
        mainClass: String,
        gameArgs: Array<String>,
        gameDir: String
    ) = withContext(Dispatchers.IO) {
        val logFile = File(gameDir, "launcher_log.txt")
        logFile.parentFile?.mkdirs()
        if (logFile.exists()) logFile.delete()

        val command = mutableListOf<String>().apply {
            add(javaBinary)
            addAll(jvmArgs)
            add("-cp")
            add(classpath)
            add(mainClass)
            addAll(gameArgs)
        }

        try {
            val processBuilder = ProcessBuilder(command)
                .directory(File(gameDir))
                .redirectErrorStream(true)

            // Setup production library native environment redirection
            val env = processBuilder.environment()
            env["HOME"] = gameDir
            env["TMPDIR"] = File(gameDir, "tmp").apply { mkdirs() }.absolutePath
            
            // Link native mobile rendering libraries if present
            val nativeLibDir = File(applicationInfo.nativeLibraryDir).absolutePath
            env["LD_LIBRARY_PATH"] = nativeLibDir

            val process = processBuilder.start()
            gameProcess = process

            logFile.printWriter().use { writer ->
                BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        writer.println(line)
                        writer.flush()
                    }
                }
            }

            val exitCode = process.waitFor()
            if (exitCode != 0) {
                File(gameDir, "crash_report_status.txt").writeText("Process exited abnormally with exit code: $exitCode")
            }

        } catch (e: Exception) {
            logFile.appendText("\nExecution Internal Failure: ${e.localizedMessage}\n")
            e.stackTrace.forEach { logFile.appendText("$it\n") }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        gameProcess?.destroy()
        executionJob.cancel()
    }
}
