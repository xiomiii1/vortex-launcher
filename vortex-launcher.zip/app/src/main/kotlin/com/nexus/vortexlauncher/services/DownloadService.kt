package com.nexus.vortexlauncher.services

import android.app.Notification
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.nexus.vortexlauncher.utils.CryptoUtils
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection

class DownloadService : Service() {

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)
    private val client = OkHttpClient()

    companion object {
        const val ACTION_START_DOWNLOAD = "com.nexus.vortexlauncher.action.START_DOWNLOAD"
        const val EXTRA_URLS = "extra_urls"
        const val EXTRA_PATHS = "extra_paths"
        const val EXTRA_HASHES = "extra_hashes"
        
        const val NOTIFICATION_ID = 101
        const val CHANNEL_ID = "download_channel"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_DOWNLOAD) {
            val urls = intent.getStringArrayExtra(EXTRA_URLS) ?: emptyArray()
            val paths = intent.getStringArrayExtra(EXTRA_PATHS) ?: emptyArray()
            val hashes = intent.getStringArrayExtra(EXTRA_HASHES) ?: emptyArray()

            startForegroundServiceNotification()

            serviceScope.launch {
                executeDownloadQueue(urls, paths, hashes)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundServiceNotification() {
        val notification = createNotification("Initializing download queue...", 0, 100)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID, 
                notification, 
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotification(content: String, progress: Int, max: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Vortex Downloader")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(max, progress, max == 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(content: String, progress: Int, max: Int) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
        manager.notify(NOTIFICATION_ID, createNotification(content, progress, max))
    }

    private suspend fun executeDownloadQueue(urls: Array<String>, paths: Array<String>, hashes: Array<String>) {
        val totalFiles = urls.size
        for (i in urls.indices) {
            val url = urls[i]
            val path = paths[i]
            val expectedHash = if (i < hashes.size) hashes[i] else ""
            val destinationFile = File(path)

            // Ensure parent directory exists
            destinationFile.parentFile?.mkdirs()

            updateNotification("Downloading file ${i + 1} of $totalFiles", 0, 100)

            var attempts = 0
            val maxAttempts = 3
            var success = false

            while (attempts < maxAttempts && !success) {
                attempts++
                if (downloadFileResilient(url, destinationFile)) {
                    if (expectedHash.isEmpty() || CryptoUtils.verifyChecksum(destinationFile, expectedHash)) {
                        success = true
                    } else {
                        destinationFile.delete() // Corrupted file removal
                    }
                }
            }
        }
    }

    private suspend fun downloadFileResilient(url: String, file: File): Boolean = withContext(Dispatchers.IO) {
        var existingLength = if (file.exists()) file.length() else 0L
        
        val requestBuilder = Request.Builder().url(url)
        if (existingLength > 0) {
            requestBuilder.header("Range", "bytes=$existingLength-")
        }

        try {
            client.newCall(requestBuilder.build()).execute().use { response ->
                val code = response.code
                if (code != HttpURLConnection.HTTP_OK && code != HttpURLConnection.HTTP_PARTIAL) {
                    if (code == 416) { // Range not satisfiable, file might already be complete or altered
                        file.delete()
                        existingLength = 0L
                        return@withContext downloadFileResilient(url, file)
                    }
                    return@withContext false
                }

                val body = response.body ?: return@withContext false
                val totalBytes = body.contentLength() + existingLength
                
                val appendMode = code == HttpURLConnection.HTTP_PARTIAL
                val outputStream = RandomAccessFile(file, "rw")
                if (appendMode) {
                    outputStream.seek(existingLength)
                } else {
                    outputStream.setLength(0)
                }

                body.byteStream().use { inputStream ->
                    val buffer = ByteArray(8192)
                    var bytesRead: Int
                    var totalDownloaded = existingLength

                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        ensureActive()
                        outputStream.write(buffer, 0, bytesRead)
                        totalDownloaded += bytesRead
                        
                        if (totalBytes > 0) {
                            val percent = ((totalDownloaded * 100) / totalBytes).toInt()
                            if (percent % 5 == 0) { // Limit updates frequency
                                updateNotification("Downloading asset: $percent%", percent, 100)
                            }
                        }
                    }
                }
                outputStream.close()
                return@withContext true
            }
        } catch (e: Exception) {
            false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
    }
}
