package com.nexus.vortexlauncher.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profiles")
data class Profile(
    @PrimaryKey val id: String,
    val name: String,
    val versionId: String, // e.g., "1.20.4"
    val gameDirectory: String,
    val javaPath: String?,
    val maxRamMb: Int,
    val jvmArguments: String,
    val modLoaderType: String, // "VANILLA", "FABRIC", "FORGE", "NEOFORGE", "QUILT"
    val modLoaderVersion: String?,
    val lastPlayed: Long
)
