package com.nexus.vortexlauncher

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.nexus.vortexlauncher.data.AppDatabase

class VortexApplication : Application() {

    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }

    override class onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val downloadChannel = NotificationChannel(
                "download_channel",
                "Asset & Runtime Downloads",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays game file downloading and installation status."
            }

            val gameChannel = NotificationChannel(
                "game_channel",
                "Game Execution",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Maintains game process lifecycle state foreground status."
            }

            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(downloadChannel)
            manager?.createNotificationChannel(gameChannel)
        }
    }
}
