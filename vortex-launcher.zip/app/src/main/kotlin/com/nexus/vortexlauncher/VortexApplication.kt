package com.nexus.vortexlauncher

import android.app.Application

class VortexApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        // Any global code or database initializations must live inside here safely
    }
}
